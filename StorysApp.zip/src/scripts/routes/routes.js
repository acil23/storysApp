import HomePage from '../pages/home/home-page';
import AboutPage from '../pages/about/about-page';
import RegisterPage from '../pages/register/register-page';
import LoginPage from '../pages/login/login-page';
import AddStoryPage from '../pages/add-story/add-story-page';

const routes = {
  '/register': new RegisterPage(),
  '/login': new LoginPage(),
  '/': new HomePage(),
  '/add-story': new AddStoryPage(),
  '/about': new AboutPage(),
};

export default routes;
